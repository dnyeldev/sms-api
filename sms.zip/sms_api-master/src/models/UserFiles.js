const { Model } = require('sequelize');
const moment = require('moment');
const _ = require('lodash');

module.exports = (sequelize, DataTypes) => {
  class UserFiles extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      const { UserFiles, EnrolleeFiles, Enrollees } = models;

      UserFiles.belongsTo(EnrolleeFiles, {
        foreignKey: 'id',
        targetKey: 'fileId',
        as: 'enrolleeFiles',
      });
    }
  }

  UserFiles.init({
    id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    type: {
      type: DataTypes.STRING
    },
    fileSize: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    filePath: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    encoding: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    createdBy: { type: DataTypes.INTEGER },
    createdAt: {
      allowNull: false,
      type: DataTypes.DATE,
      get() { return moment(this.getDataValue('createdAt')).format('YYYY-MM-DD HH:mm:ss'); },
    },
    updatedBy: { type: DataTypes.INTEGER },
    updatedAt: {
      type: DataTypes.DATE,
      get() { return moment(this.getDataValue('updatedAt')).format('YYYY-MM-DD HH:mm:ss'); },
    },
    deletedBy: { type: DataTypes.INTEGER },
    deletedAt: {
      type: DataTypes.DATE,
      get() { return this.getDataValue('deletedAt') && moment(this.getDataValue('deletedAt')).format('YYYY-MM-DD HH:mm:ss'); },
    },
  }, {
    sequelize,
    modelName: 'UserFiles',
    paranoid: true,
    timestamps: true,
    hooks: {
      beforeDestroy: (model, options) => {
        const { deletedBy } = options;

        // workaround to log who deleted the record
        if (deletedBy) { model.update({ deletedBy }); }
      },
    },
  });

  return UserFiles;
};
