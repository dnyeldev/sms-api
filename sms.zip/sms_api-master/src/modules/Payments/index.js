const getRefPayments = require('./getRefPayments')
const payStudent = require('./payStudent')

module.exports = {
  getRefPayments,
  payStudent
}
