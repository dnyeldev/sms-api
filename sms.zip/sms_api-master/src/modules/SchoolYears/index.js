const createSchoolYear = require('./createSchoolYear')
const getSchoolYear = require('./getSchoolYear')
const getSchoolYears = require('./getSchoolYears')

module.exports = {
  createSchoolYear,
  getSchoolYear,
  getSchoolYears
};
