const enrollStudent = require('./enrollStudent')
const getEnrollees = require('./getEnrollees')

module.exports = {
  enrollStudent,
  getEnrollees
};
