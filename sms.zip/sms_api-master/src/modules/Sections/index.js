const createSection = require('./createSection')
const getSection = require('./getSection')
const getSections = require('./getSections')

module.exports = {
  createSection,
  getSection,
  getSections
};
