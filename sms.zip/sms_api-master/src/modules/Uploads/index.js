const uploadFile = require('./uploadFile')

module.exports = {
  uploadFile
};
