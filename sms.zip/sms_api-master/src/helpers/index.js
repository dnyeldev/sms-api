const sequelizeHelper = require('./sequelizeHelper')

module.exports = {
  sequelizeHelper,
};
