module.exports = [
  'PENDING',
  'ENROLLMENT',
  'ONGOING',
  'CLOSED'
]
