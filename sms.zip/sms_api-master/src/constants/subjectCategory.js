module.exports = [
  'ENGLISH',
  'MATH',
  'AP',
  'ESP',
  'TLE',
  'MAPEH',
  'SCIENCE',
  'FILIPINO'
]
